
// App state
let state={
    level:1,
    arr:[],
    user_inp:[],
    btn_state:false,
    status:true

}
alert("Please click the boxes in the same order they blink!")
// Component selection
const btn=document.querySelector('.btn');
let all_child_elements=document.querySelectorAll(".child_div") ;
all_child_elements=[...all_child_elements];

all_child_elements.forEach(element=>{
    
    element.addEventListener('click',()=>{
        state.user_inp.push(parseInt(element.id));
        validate();
    })
    
})
// console.log(all_child_elements);

// Function call
btn.addEventListener('click',()=>{
    rand(state.level);
})

function rand(num){
    state.arr=[];
    state.user_inp=[];
    btn.disabled=false;


 
    for(let i=0;i<num;i++){
        const rand_num= Math.ceil(Math.random()*4);
        state.arr.push(rand_num);
        // console.log("pushing value");
        
    }
    console.log(state.arr);
    
    display();

    
}


// add and remove classlist// pattern display

function display(){
   
    for(let i=1;i<=state.arr.length;i++){
        if(i===state.arr.length)
        {
            btn.disabled=true;
            state.btn_state=true;
           
            
        }
    
        let component=``
        
        setTimeout(() => {
        component=document.getElementById(state.arr[i-1]);
        // console.log(component);
        component.classList.add("selected");
            setTimeout(() => {
                component.classList.remove("selected");         
            },  1000);     
        }, i* 1500);
    }

    



} 
    // check the length of the arrays
function validate(){
    // if userinput length is equal to random number length then check the values, else nothing
    state.arr.length===state.user_inp.length?checkValues(): console.log("not yet");
    

}

// check values

function checkValues(){
    // console.log("user inp and arr");
    
    // console.log(state.user_inp);
    // console.log(state.arr);
    
    
    
    for(let i=0;i<state.arr.length;i++){
        if(state.arr[i]===state.user_inp[i])
        {
            state.status=true;
        }
        else{
           state.status=false;
            break;
        }
        
    }
    console.log(`status= ${state.status}`);
    
    if(state.status){
        levelUp();
    }
    else{
        reset();
    }

}

// LevelUp

function callRand()
{
    setTimeout(() => {
        rand(state.level);
    }, 1500);
}

function levelUp(){
    if(state.level<10)
    {
        state.level=state.level+1;
        let lev= document.querySelector('.level');
        lev.innerText=`Level : ${state.level}`;
        alert("yay, Leveled Up");
        callRand();
    }

    else{
        alert("game complete- You win");
        state.level=1;
        state.btn_state=false;
        state.status=true;
        alert("Click 'Play' to play again");
        btn.disabled=false;
        }
}

function reset(){
    state.level=1;
    alert("Oops! Thats wrong! Back to level 1");
    btn.disabled=false;

}